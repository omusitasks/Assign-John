# set working directory

# setwd("C:/Users/user/Downloads/Mbooni")

# Load required libraries
library(ggplot2)
library(dplyr)
library(lubridate)
library(forecast)

# Read the dataset
data <- read.csv("EXJPUS.csv")

# Convert DATE column to Date type
data$DATE <- as.Date(data$DATE)



# Questions:
############################## question 1 ##############################
## 1.0 Create a plot of the level of the time series. 
## Label the axes appropriately. Attach the plot here. 
## Explain the importance of the plot. 



# Plot the time series
ggplot(data, aes(x = DATE, y = EXJPUS)) +
  geom_line() +
  labs(x = "Date", y = "Exchange Rate (JPY to USD)",
       title = "Exchange Rate (JPY to USD) Over Time")


############################## question 2 ##############################

## Create a plot for the level, the log, the seasonal difference, and double difference of the time series. 
## Attach the plot here. Explain the importance of the plot. 


# Compute seasonal difference
seasonal_diff <- diff(data$EXJPUS, lag = 12)

# Remove first 11 NA values
seasonal_diff <- seasonal_diff[!is.na(seasonal_diff)]

# Compute log transformation
data$log <- log(data$EXJPUS)

# Truncate dataset to match the length of seasonal_diff
data <- data[-(1:12), ]

# Add seasonal difference to the dataset
data$seasonal_diff <- seasonal_diff

# Add double difference to the dataset
data$double_diff <- double_diff


# Plot each transformation
plots <- list()

# Plot level
plots$level <- ggplot(data, aes(x = DATE, y = EXJPUS)) +
  geom_line() +
  labs(x = "Date", y = "Exchange Rate (JPY to USD)",
       title = "Level of Exchange Rate (JPY to USD) Over Time")

# Plot log
plots$log <- ggplot(data, aes(x = DATE, y = log)) +
  geom_line() +
  labs(x = "Date", y = "Log of Exchange Rate (JPY to USD)",
       title = "Log Transformation of Exchange Rate (JPY to USD) Over Time")



# Plot seasonal difference
plots$seasonal_diff <- ggplot(data, aes(x = DATE, y = seasonal_diff)) +
  geom_line() +
  labs(x = "Date", y = "Seasonal Difference of Exchange Rate (JPY to USD)",
       title = "Seasonal Difference of Exchange Rate (JPY to USD) Over Time")


# Print and save plots
for (plot_type in names(plots)) {
  print(plots[[plot_type]])
}




############################## question 3 ##############################

# Conduct unit root tests for the log, the seasonal difference, and the double difference of the time series. 
# Attach the results here and explain them. 

# Load required libraries
library(urca)

# Conduct ADF test for the log-transformed series
adf_log <- ur.df(data$log, type = "drift", lags = 1)
summary(adf_log)

# Conduct ADF test for the seasonal difference
adf_seasonal_diff <- ur.df(data$seasonal_diff, type = "drift", lags = 1)
summary(adf_seasonal_diff)

# Conduct ADF test for the double difference
adf_double_diff <- ur.df(data$double_diff, type = "drift", lags = 1)
summary(adf_double_diff)



############################## question 4 ##############################

## Create a plot of the ACF and PACF for the seasonal difference of the time series. 
## Explain the purpose of these plots and their meaning. 



ts_data <- ts(data$EXJPUS, start = c(1971, 1), frequency = 12)
seasonal_diff <- diff(ts_data, lag = 12)

par(mfrow=c(2,1))
acf(seasonal_diff, main="ACF of Seasonal Differenced Time Series")
pacf(seasonal_diff, main="PACF of Seasonal Differenced Time Series")

ggAcf(seasonal_diff) + labs(title = "ACF of Seasonal Differenced Time Series")
ggPacf(seasonal_diff) + labs(title = "PACF of Seasonal Differenced Time Series")





############################## question 5 ##############################

## Create a plot of the ACF and PACF for the double difference of the time series. 
## Explain the purpose of these plots and their meaning. 

ts_data <- ts(data$EXJPUS, start = c(1971, 1), frequency = 12)
double_diff <- diff(diff(ts_data, lag = 1), lag = 12)

par(mfrow=c(2,1))
acf(double_diff, main="ACF of Double Differenced Time Series")
pacf(double_diff, main="PACF of Double Differenced Time Series")


ggAcf(double_diff) + labs(title = "ACF of Double Differenced Time Series")
ggPacf(double_diff) + labs(title = "PACF of Double Differenced Time Series")



############################## question 7 ##############################


# Fit the two ARIMA models you identified in item 7 and an auto ARIMA model to the time series data. 
# Compute the information criteria and identify the best model and attach the results here. Identify the best model. 

# Create a time series object
ts_data <- ts(data$EXJPUS, start = c(1971, 1), frequency = 12)

# Fit ARIMA models
model1 <- arima(ts_data, order = c(1, 1, 1), seasonal = list(order = c(0, 1, 1)))
model2 <- arima(ts_data, order = c(0, 1, 1), seasonal = list(order = c(1, 1, 1)))
auto_model <- auto.arima(ts_data)

# Compute information criteria
aic_model1 <- AIC(model1)
aic_model2 <- AIC(model2)
aic_auto_model <- AIC(auto_model)

bic_model1 <- BIC(model1)
bic_model2 <- BIC(model2)
bic_auto_model <- BIC(auto_model)

# Print results
cat("Model 1 (ARIMA(1, 1, 1)(0, 1, 1)12):\n")
cat("AIC:", aic_model1, "\n")
cat("BIC:", bic_model1, "\n\n")

cat("Model 2 (ARIMA(0, 1, 1)(1, 1, 1)12):\n")
cat("AIC:", aic_model2, "\n")
cat("BIC:", bic_model2, "\n\n")

cat("Auto ARIMA Model:\n")
cat("AIC:", aic_auto_model, "\n")
cat("BIC:", bic_auto_model, "\n\n")



############################## question 9 ##############################

## Generate residual diagnostic plots for the best ARIMA model and explain them. 
## Attach the plots here. 


# Create a time series object
ts_data <- ts(data$EXJPUS, start = c(1971, 1), frequency = 12)

# Fit the best ARIMA model
best_model <- arima(ts_data, order = c(0, 1, 1), seasonal = list(order = c(1, 1, 1)))

# Generate residual diagnostic plots
checkresiduals(best_model)


############################## question 10 ##############################


## Conduct an autocorrelation test for the residuals of the best ARIMA model and explain it. Attach the results and the R code for this test here.


# Create a time series object
ts_data <- ts(data$EXJPUS, start = c(1971, 1), frequency = 12)

# Fit the best ARIMA model
best_model <- arima(ts_data, order = c(0, 1, 1), seasonal = list(order = c(1, 1, 1)))

# Conduct Ljung-Box test for residuals
ljung_box_test <- Box.test(residuals(best_model), lag = 12, type = "Ljung-Box")

# Print test results
ljung_box_test



############################## question 11 ##############################

## Use the best ARIMA model to forecast three years of the time series. 
## Attach the plot of the forecast here.


# Create a time series object
ts_data <- ts(data$EXJPUS, start = c(1971, 1), frequency = 12)

# Fit the best ARIMA model
best_model <- arima(ts_data, order = c(0, 1, 1), seasonal = list(order = c(1, 1, 1)))

# Forecast three years (36 months) ahead
forecast_best <- forecast(best_model, h = 36)

# Plot the forecast
plot(forecast_best, main = "Forecast of EXJPUS Time Series")


############################## question 12 ##############################


## Print the Fable that shows the forecast of the three years of the time series and attach it here. 

# Print the summary of the forecast
summary(forecast_best)


############################## question 15 ##############################


## Use bootstrapping to generate 1000 simulations of the time series yt. 
## Use block size = 24 to cover two years of data. 
## Fit the best ARIMA model you identified in question 8 to each of the simulated time series and create a plot of the 1000 ARIMA bootstrapped forecasts. 
## Attach the plot here.



# Create a time series object
ts_data <- ts(data$EXJPUS, start = c(1971, 1), frequency = 12)

# Number of simulations
n_simulations <- 1000

# Block size for bootstrapping (covers two years of data)
block_size <- 24

# Function to generate one bootstrapped series
generate_bootstrapped_series <- function(data, block_size) {
  n <- length(data)
  n_blocks <- floor(n / block_size)
  bootstrapped_series <- numeric(n)
  
  for (i in 1:n_blocks) {
    block_indices <- sample((1:n)[(i - 1) * block_size + 1 : (i * block_size)], replace = TRUE)
    bootstrapped_series[(i - 1) * block_size + 1 : (i * block_size)] <- data[block_indices]
  }
  
  return(ts(bootstrapped_series, start = start(data), frequency = frequency(data)))
}

# Generate 1000 bootstrapped series
bootstrapped_series <- lapply(1:n_simulations, function(x) generate_bootstrapped_series(ts_data, block_size))

# Function to fit ARIMA model to each bootstrapped series and generate forecasts
generate_forecasts <- function(series) {
  arima_model <- auto.arima(series)
  return(forecast(arima_model, h = 36))
}

# Generate forecasts for each bootstrapped series
bootstrapped_forecasts <- lapply(bootstrapped_series, generate_forecasts)

# Plot the 1000 ARIMA bootstrapped forecasts
plot(bootstrapped_forecasts[[1]], main = "1000 ARIMA Bootstrapped Forecasts", xlab = "Time", ylab = "Value", col = "blue", xlim = c(1971, 1976))

for (i in 2:n_simulations) {
  lines(bootstrapped_forecasts[[i]]$mean, col = "blue")
}





############################## question 16 ##############################

## Create a plot that shows the three-year forecasts of your best ARIMA model when it is fit directly to the time series and the three-year bagged forecasts generated from the bootstrapped forecasts in question 15.

# Fit the best ARIMA model to the original time series
best_model <- arima(ts_data, order = c(0, 1, 1), seasonal = list(order = c(1, 1, 1)))

# Generate forecasts for the next three years using the best ARIMA model
forecast_best <- forecast(best_model, h = 36)

# Extract the median of the bootstrapped forecasts for each forecast horizon
bootstrapped_median <- colMeans(sapply(bootstrapped_forecasts, function(x) x$mean))

# Plot the forecasts from the best ARIMA model
plot(forecast_best, main = "Comparison of Forecasts", xlab = "Time", ylab = "Value", col = "blue")

# Plot the median bootstrapped forecasts
lines(time(forecast_best$mean), bootstrapped_median, col = "red")

# Add a legend
legend("topright", legend = c("ARIMA Model Forecast", "Bootstrapped Median Forecast"), col = c("blue", "red"), lty = 1)




############################## question 17 ##############################

## Print the tsibble that shows the ARIMA bagged forecasts for the three years of the time series and attach it here.

# Ensure bootstrapped_forecasts exists
if (exists("bootstrapped_forecasts")) {
  # Extract the forecasted values from the bootstrapped forecasts
  forecast_values <- lapply(bootstrapped_forecasts, function(x) x$mean)
  
  # Combine the forecasted values into a single matrix
  forecast_matrix <- do.call(cbind, forecast_values)
  
  # Convert the matrix to a tsibble
  library(tsibble)
  forecast_tsibble <- as_tsibble(forecast_matrix)
  
  # Print the tsibble
  print(forecast_tsibble)
} else {
  print("bootstrapped_forecasts not found.")
}


