CREATE DATABASE FurnitureItems
GO

USE FurnitureItems
GO

CREATE TABLE FurnitureInventory
(
	ProductCode VARCHAR(15) PRIMARY KEY NOT NULL,
	ProductDescription VARCHAR(150) NOT NULL,
	ProductLine VARCHAR(15) NOT NULL,
	ProductGroup VARCHAR(15) NOT NULL,
	ProductColour VARCHAR(15) NOT NULL,
	[Length] INT NOT NULL,
	Width INT NOT NULL,
	Height INT NOT NULL,
	[Weight] INT NOT NULL,
	Price DECIMAL(10,2) NOT NULL,
	Class CHAR(1) NOT NULL,
	IOH INT NULL
)