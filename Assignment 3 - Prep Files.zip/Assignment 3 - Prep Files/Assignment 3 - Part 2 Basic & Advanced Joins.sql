USE FlightTrackerHKaveri0706;
GO

-- Section #3: Basic Joins
-- Step 1
SELECT 
    Passenger.FirstName, 
    Passenger.LastName, 
    Passenger.Nationality
FROM 
    Passenger
INNER JOIN 
    FlightDetails ON Passenger.ID = FlightDetails.PassengerID
ORDER BY 
    Passenger.Nationality, 
    Passenger.LastName, 
    Passenger.FirstName;



-- Step 2
SELECT 
    Flights.FlightNumber, 
    Luggage.ItemWeight, 
    Luggage.Oversized
FROM 
    Luggage
INNER JOIN 
    Flights ON Luggage.FlightID = Flights.ID
ORDER BY 
    Flights.FlightNumber, 
    Luggage.ItemWeight DESC;




-- Step 3
SELECT 
    Planes.Manufacture, 
    Planes.Model, 
    Planes.PassengerCapacity, 
    Planes.CargoCapacity, 
    Planes.FuelRange, 
    Flights.FlightNumber
FROM 
    Planes
LEFT JOIN 
    Flights ON Planes.ID = Flights.PlaneID;




-- Step 4
SELECT 
    Passenger.FirstName, 
    Passenger.LastName, 
    Passenger.Nationality, 
    Luggage.ItemWeight
FROM 
    Passenger
LEFT JOIN 
    Luggage ON Passenger.ID = Luggage.PassengerID
WHERE 
    Luggage.ItemWeight IS NULL
ORDER BY 
    Passenger.Nationality, 
    Luggage.ItemWeight;



-- Section #3: Advanced Joins
-- Step 1
SELECT 
    Flights.FlightNumber, 
    COUNT(FlightDetails.PassengerID) AS PassengerCount
FROM 
    Flights
INNER JOIN 
    FlightDetails ON Flights.ID = FlightDetails.FlightID
GROUP BY 
    Flights.FlightNumber
ORDER BY 
    PassengerCount;





-- Step 2
SELECT 
    Flights.FlightNumber, 
    Planes.Manufacture, 
    Planes.Model, 
    Planes.CargoCapacity, 
    COUNT(Luggage.ID) AS LuggageCount, 
    SUM(Luggage.ItemWeight) AS TotalItemWeight
FROM 
    Flights
INNER JOIN 
    Planes ON Flights.PlaneID = Planes.ID
INNER JOIN 
    Luggage ON Flights.ID = Luggage.FlightID
GROUP BY 
    Flights.FlightNumber, 
    Planes.Manufacture, 
    Planes.Model, 
    Planes.CargoCapacity
ORDER BY 
    LuggageCount DESC;




-- Step 3
SELECT 
    Flights.FlightNumber, 
    Planes.Manufacture, 
    Planes.Model, 
    Flights.Departure, 
    Flights.Destination, 
    Passenger.Nationality, 
    COUNT(DISTINCT FlightDetails.PassengerID) AS PassengerCount, 
    COUNT(Luggage.ID) AS LuggageCount, 
    SUM(Luggage.ItemWeight) AS TotalItemWeight, 
    AVG(Luggage.ItemWeight) AS AvgItemWeight
FROM 
    Flights
INNER JOIN 
    Planes ON Flights.PlaneID = Planes.ID
INNER JOIN 
    FlightDetails ON Flights.ID = FlightDetails.FlightID
INNER JOIN 
    Passenger ON FlightDetails.PassengerID = Passenger.ID
LEFT JOIN 
    Luggage ON Flights.ID = Luggage.FlightID AND FlightDetails.PassengerID = Luggage.PassengerID
GROUP BY 
    Flights.FlightNumber, 
    Planes.Manufacture, 
    Planes.Model, 
    Flights.Departure, 
    Flights.Destination, 
    Passenger.Nationality
HAVING 
    COUNT(DISTINCT FlightDetails.PassengerID) > 5;

