CREATE DATABASE FurnitureItems
GO

USE FurnitureItems
GO

CREATE TABLE FurnitureInventory
(
	ProductCode VARCHAR(15) PRIMARY KEY NOT NULL,
	ProductDescription VARCHAR(150) NOT NULL,
	ProductLine VARCHAR(15) NOT NULL,
	ProductGroup VARCHAR(15) NOT NULL,
	ProductColour VARCHAR(15) NOT NULL,
	[Length] INT NOT NULL,
	Width INT NOT NULL,
	Height INT NOT NULL,
	[Weight] INT NOT NULL,
	Price DECIMAL(10,2) NOT NULL,
	Class CHAR(1) NOT NULL,
	IOH INT NULL
)

SELECT * FROM FurnitureInventory;


-- Run this SELECT statement to test the query before creating the view
SELECT 
    ProductLine,
    COUNT(*) AS ItemCount,
    SUM(IOH) AS TotalInventory,
    SUM(IOH * Price) AS TotalInventoryValue
FROM 
    FurnitureInventory
GROUP BY 
    ProductLine;

-- Now, create the view in a separate batch
GO

CREATE VIEW ProductLines AS
SELECT 
    ProductLine,
    COUNT(*) AS ItemCount,
    SUM(IOH) AS TotalInventory,
    SUM(IOH * Price) AS TotalInventoryValue
FROM 
    FurnitureInventory
GROUP BY 
    ProductLine;



-- Run this SELECT statement to test the query before creating the view
SELECT 
    ProductLine,
    ProductColour,
    COUNT(*) AS ItemCount,
    AVG(Price) AS AveragePrice,
    SUM(IOH) AS TotalInventory
FROM 
    FurnitureInventory
GROUP BY 
    ProductLine, 
    ProductColour;

-- Now, lets' create the view in a separate batch
GO

CREATE VIEW ProductGroups AS
SELECT 
    ProductLine,
    ProductColour,
    COUNT(*) AS ItemCount,
    AVG(Price) AS AveragePrice,
    SUM(IOH) AS TotalInventory
FROM 
    FurnitureInventory
GROUP BY 
    ProductLine, 
    ProductColour;




-- Run this SELECT statement to test the query before creating the view
SELECT 
    Class,
    COUNT(*) AS ItemCount,
    AVG(Price) AS AveragePrice,
    SUM(IOH) AS TotalInventory,
    SUM(IOH * Price) AS TotalInventoryValue
FROM 
    FurnitureInventory
GROUP BY 
    Class;

-- Now, create the view in a separate batch
GO

CREATE VIEW ProductClasses AS
SELECT 
    Class,
    COUNT(*) AS ItemCount,
    AVG(Price) AS AveragePrice,
    SUM(IOH) AS TotalInventory,
    SUM(IOH * Price) AS TotalInventoryValue
FROM 
    FurnitureInventory
GROUP BY 
    Class;
